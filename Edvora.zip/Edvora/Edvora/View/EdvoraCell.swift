//
//  EdvoraCell.swift
//  Edvora
//
//  Created by Osama Farag on 07/02/2022.
//

import UIKit

class EdvoraCell: UITableViewCell {

    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var ProductName: UILabel!
    @IBOutlet weak var BrandName: UILabel!
    @IBOutlet weak var Price: UILabel!
    @IBOutlet weak var Location: UILabel!
    @IBOutlet weak var Date: UILabel!
    @IBOutlet weak var Descripion: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
