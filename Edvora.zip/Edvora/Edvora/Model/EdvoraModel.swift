//
//  EdvoraModel.swift
//  Edvora
//
//  Created by Osama Farag on 06/02/2022.
//
import Foundation
struct EdvoraModel {
    
    var length : Int
    var product_name : String
    var brand_name : String
    var price : Int
    var address : [Address]
    var discription : String
    var date : Date
    //let time : Date
    var image : String
}
