//
//  EdvoraBrain.swift
//  Edvora
//
//  Created by Osama Farag on 06/02/2022.
//

import Foundation

protocol EdvoraManagerDelgate {
    func didUpdateEdvora(_ edvoramanager : EdvoraManager , edvora : EdvoraModel)
    func didYouFailOnError(error : Error)
}
struct EdvoraManager {
    let EdvoraUrl = "https://assessment-edvora.herokuapp.com/"
    var delegate : EdvoraManagerDelgate?
    
    func performRequest(indexPath : Int)  {
        let url = URL(string: EdvoraUrl)!
        let session = URLSession(configuration: .default)
        let task = session.dataTask(with : url) { (data, response, error) in
            if error != nil {
                delegate?.didYouFailOnError(error: error!)
                return
            }
            if let safeData = data {
                if let edvora = parseJson(edvoraData: safeData, indedxPath: indexPath){
                    delegate?.didUpdateEdvora(self, edvora: edvora)
                }
            }
        }
        task.resume()
    }
    
    func parseJson(edvoraData : Data , indedxPath : Int) -> EdvoraModel!{
        let decoder = JSONDecoder()
        do{
        let decodedData = try decoder.decode(EdvoraData.self, from: edvoraData)
            
            // get data from Json Decoder to EdvoraModel structure
            
            let edvora = EdvoraModel(length: decodedData.length.count, product_name: decodedData.length[indedxPath].product_name, brand_name: decodedData.length[indedxPath].brand_name, price:decodedData.length[indedxPath].price, address: decodedData.length[indedxPath].address, discription: decodedData.length[indedxPath].discription, date:decodedData.length[indedxPath].date , image: decodedData.length[indedxPath].image)
            return edvora
        }catch{
            delegate?.didYouFailOnError(error: error)
            return nil
        }
    }
}
