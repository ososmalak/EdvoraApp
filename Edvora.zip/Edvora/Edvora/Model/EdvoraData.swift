//
//  EdvoraModel.swift
//  Edvora
//

import Foundation
struct EdvoraData : Codable{
    let length : [Count]
}
struct Count : Codable{
    //let lenght : Int
    let product_name : String
    let brand_name : String
    let price : Int
    let address : [Address]
    let discription : String
    let date : Date
    //let time : Date
    let image : String
}
struct Address : Codable{
    let state : String
    let city : String
}
