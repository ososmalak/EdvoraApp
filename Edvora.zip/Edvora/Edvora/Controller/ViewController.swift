//
//  ViewController.swift
//  Edvora
//
//  Created by Osama Farag on 06/02/2022.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var TableView: UITableView!
    var edvoramanager = EdvoraManager()
    //let edvoradata = EdvoraData()
    override func viewDidLoad() {
        super.viewDidLoad()
        edvoramanager.performRequest(indexPath: 0)
        // Do any additional setup after loading the view.
        TableView.register(UINib(nibName: "EdvoraCell", bundle: nil), forCellReuseIdentifier: "ReusableCell")
    }
    
    
    
}
extension ViewController : UITableViewDataSource , EdvoraManagerDelgate{
    func didUpdateEdvora(_ edvoramanager: EdvoraManager, edvora: EdvoraModel) {
        
    }
    
    func didYouFailOnError(error: Error) {
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //return EdvoraModel.length.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell  = TableView.dequeueReusableCell(withIdentifier: "ReusableCell", for: indexPath) as! EdvoraCell
        let rowNumber : Int = indexPath.row
        edvoramanager.performRequest(indexPath: rowNumber)
        return cell
        
    }
    
}



